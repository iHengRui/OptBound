# SUM-C-NS-SFO-TV-COMP-PROX

## 1. Problem Formulation

Consider the finite-sum convex composite decentralized optimization problem with time-varying communication matrices and access to incremental first-order and proximal oracles:

$$
\min_{x\in\mathbb R^d}\phi(x):=f(x)+h(x),
\qquad
f(x):=\frac{1}{n}\sum_{i=1}^n f_i(x),
$$

where the local finite-sum objective

$$
f_i(x):=\frac{1}{m}\sum_{\xi\in D_i}F_i(x;\xi),
\qquad |D_i|=m,
$$

is private to node $i\in[n]$. The shared regularizer has the exact proximal oracle

$$
O_{\operatorname{prox}_h}(v;\eta)
:=\operatorname{prox}_{\eta h}(v)
:=\operatorname*{argmin}_{y\in\mathbb R^d}
\left\{h(y)+\frac{1}{2\eta}\|y-v\|^2\right\}.
$$

Here $\eta>0$.

The local incremental first-order oracle is

$$
O_i(x,\xi):=\nabla F_i(x;\xi),
\qquad \xi\in D_i.
$$

One gradient-oracle call means one exact component-gradient query, not evaluation of the full local gradient $\nabla f_i(x)$. The algorithm may choose the queried component and may be randomized.

The nodes communicate through a sequence of time-varying mixing matrices $(W_q)_{q\ge0}$, where $q$ counts communication-matrix updates and $t$ counts algorithm iterations. The matrix $W_q$ is in force after update $q$, with $W_0$ the initial matrix. Updates occur every fixed absolute constant number of iterations, independently of whether communication occurs:

$$
Z^+=W_qZ,
\qquad
Z=(z_1^{\top},\ldots,z_n^{\top})^{\top}.
$$

Let

$$
\mathcal N_q(i):=\{i\}\cup\{j\in[n]:w_{ij,q}>0\}.
$$

Node $i$ knows the $i$-th row of $W_q$ and can access only the weighted sum $\sum_{j\in\mathcal N_q(i)}w_{ij,q}z_j$, not the individual vectors $\{z_j\}_{j\in\mathcal N_q(i)}$. One communication round may use the same $W_q$ to mix at most $c$ vectors in $\mathbb R^d$ per node, where $c$ is an absolute constant independent of all problem parameters. This convention covers methods that simultaneously communicate, for example, a primal variable and a gradient-tracking variable.

Fix $L,R>0$, $m,n,p\in\mathbb N$, and $\rho\in[0,1)$. All nodes start from the common initial point $x_0$. Define the function class

$$
\begin{aligned}
\mathcal F_{L,R,m}:=\Bigl\{(f)_\dagger=(f_1,\ldots,f_n,h,x_0):\;&
x_0\in\mathbb R^d,\\
&F_i(\cdot;\xi)\text{ is convex and }L\text{-smooth for every }i,\xi,\\
&h\text{ is proper, closed, convex, and exactly proximable},\\
&\operatorname*{argmin}_{x\in\mathbb R^d}\phi(x)\ne\varnothing,\\
&\text{there exists }x^\star\in\operatorname*{argmin}_{x\in\mathbb R^d}\phi(x)
\text{ with }\|x_0-x^\star\|\le R
\Bigr\}.
\end{aligned}
$$

Define the oracle class

$$
\mathcal O_{\mathrm{IFO},\mathrm{prox}}
:=\Bigl\{(O)_\dagger=(O_1,\ldots,O_n,O_{\operatorname{prox}_h}):
O_i(x,\xi)=\nabla F_i(x;\xi),\ \xi\in D_i,
\ O_{\operatorname{prox}_h}(v;\eta)=\operatorname{prox}_{\eta h}(v)
\Bigr\}.
$$

Let $J:=(1/n)\mathbf 1\mathbf 1^{\top}$. Here $p$ counts consecutive matrix-update intervals. Define the time-varying communication class by the quantitative product-contraction condition

$$
\begin{aligned}
\mathcal W_{p,\rho}:=\Bigl\{(W)_\dagger=(W_q)_{q\ge0}:\;&
W_q\ge0,\quad
\mathbf 1^{\top}W_q=\mathbf 1^{\top},\quad
W_q\mathbf 1=\mathbf 1,\\
&\left\|W_{q+p-1}\cdots W_q-J\right\|_2\le\rho
\quad\text{for every }q\ge0
\Bigr\}.
\end{aligned}
$$

The parameters $n,m,L,R,p,\rho$ are available to the algorithm, as is the current local row of $W_q$. Define the algorithm class

$$
\mathcal A:=\Bigl\{A:\text{randomized zero-respecting algorithms using, per node and iteration, at most one component-gradient query, one exact proximal query, and one communication round}\Bigr\}.
$$

Here, zero-respecting requires that no node can query its oracle at, communicate, or output a vector with a non-zero entry in any coordinate that is zero in its initial point, in all of its previous oracle outputs, and in all of the mixed messages it has received.

For lower-bound constructions, the dimension $d$ may be chosen sufficiently large. Define the averaged output

$$
\widehat x_t:=\frac{1}{n}\sum_{i=1}^n\widehat x_{t,i}
$$

and the convergence metric

$$
T_\varepsilon(A,(f)_\dagger,(O)_\dagger,(W)_\dagger)
:=\inf\left\{t\ge0:
\mathbb E\left[\phi(\widehat x_t)-\phi(x^\star)\right]\le\varepsilon
\right\}.
$$

The expectation is over all internal randomness of the algorithm, including any randomized choice of component indices. 

The final problem is to determine the order of

$$
\inf_{A\in\mathcal A}
\sup_{(f)_\dagger\in\mathcal F_{L,R,m}}
\sup_{(O)_\dagger\in\mathcal O_{\mathrm{IFO},\mathrm{prox}}}
\sup_{(W)_\dagger\in\mathcal W_{p,\rho}}
T_\varepsilon(A,(f)_\dagger,(O)_\dagger,(W)_\dagger).
$$

## 2. Task Description

The goal is to give matching upper and lower bounds for this inf-sup problem.

- For the upper bound, construct an algorithm and prove its $\mathcal O(\cdot)$ iteration complexity uniformly over the declared function, oracle, and communication classes. An implementation may use an absolute constant number of oracle calls, proximal calls, or communication rounds in one algorithmic iteration: this can be represented by splitting that iteration into a constant number of unit iterations while respecting the scheduled matrix updates, which preserves the order of the iteration complexity. All waiting and alignment iterations are charged. For clarity, such constant-budget implementations are encouraged instead of literally expanding every substep into separate iterations.
- For the lower bound, for every admissible algorithm construct a hard function, oracle, and communication sequence giving an $\Omega(\cdot)$ iteration lower bound.
- State the dependence on $n,m,L,R,p,\rho$, and $\varepsilon$. Work in small $\varepsilon$ scenario and do not omit a term merely because its $\varepsilon$ dependence is dominated when its dependence on another retained parameter differs.
- Combine matching bounds to obtain the optimal $\Theta(\cdot)$ order. Bounds matching up to logarithmic factors may be written with $\widetilde{\mathcal O}$, $\widetilde{\Omega}$, and $\widetilde{\Theta}$.

Every reported bound must retain the dependence on all declared parameters, including terms that are lower order in $\varepsilon$ but have different dependence on other parameters. For example, a rate of the form

$$
\Theta\left(
\frac{L\Delta\sigma^2}{n\varepsilon^2}
+\frac{L\Delta}{\varepsilon}
\right)
$$

must keep both terms: the second term is lower order in $\varepsilon$ than the first, but it does not contain the first term's $1/n$ linear-speedup factor and therefore cannot be absorbed into it.

## 3. Relaxation Rules

Only the standard problem receives full credit. Results under explicit alternatives may receive partial credit. For function, oracle, and communication classes, a class relaxation is marked $(-)$ and a class restriction is marked $(+)$. For the algorithm class, enlarging the admissible class is marked $(+)$ and adding an algorithmic restriction is marked $(-)$. For the convergence metric, adding a success requirement is marked $(-)$ and weakening the success criterion is marked $(+)$.

Usually, a $(+)$ alternative weakens the upper-bound conclusion and strengthens the lower-bound conclusion, whereas a $(-)$ alternative strengthens the upper-bound conclusion and weakens the lower-bound conclusion.

Common alternatives include:

- Function class: require only each $f_i$ to be $L$-smooth, rather than every component $F_i(\cdot;\xi)$, $(-)$; require only the average $f$ to be $L$-smooth, $(-)$; impose a common minimizer or an additional bounded-gradient condition, $(+)$.
- Oracle class: replace algorithm-selected component queries by indices drawn independently and uniformly from $D_i$ by the oracle, $(+)$.
- Communication class: weaken or remove the $(p,\rho)$ product-contraction bound, $(-)$; require $p$-periodicity, or symmetry, $(+)$.
- Algorithm class: drop the zero-respecting requirement, $(+)$.
- Convergence metric: additionally require a per-node objective or consensus condition, $(-)$.

Only alternatives preserving convex composite finite-sum optimization, component-gradient access, and decentralized communication are admissible. Changing to non-convex, strongly convex, or PL geometry; replacing decentralized communication by centralized communication; or treating a full local gradient as one component-oracle query is forbidden. These forbidden changes are not alternatives in the preceding list.

## 4. Related Work

- *Decentralized Stochastic Proximal Gradient Descent with Variance Reduction over Time-varying Networks* ([arXiv:2112.10389](https://arxiv.org/abs/2112.10389)).
